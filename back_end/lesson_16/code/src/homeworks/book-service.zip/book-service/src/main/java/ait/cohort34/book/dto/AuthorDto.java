package ait.cohort34.book.dto;

import java.time.LocalDate;

import lombok.Getter;

@Getter
public class AuthorDto {
	String name;
	LocalDate birthDate;
}
