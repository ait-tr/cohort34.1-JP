package ait.cohort34.student.dto;

import lombok.Getter;

@Getter
public class StudentUpdateDto {
    private String name;
    private String password;
}
