package org.demo34springapp.entity;

public enum TaskStatus {
    OPEN,
    CLOSE,
    OnHOLD
}
