package org.demo34springapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo34SpringAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
