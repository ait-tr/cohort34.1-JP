package ait.cohort34.post.dto;

import lombok.Getter;

@Getter
public class NewCommentDto {
    String message;
}
