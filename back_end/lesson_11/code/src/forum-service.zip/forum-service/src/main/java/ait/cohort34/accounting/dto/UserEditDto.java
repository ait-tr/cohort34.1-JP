package ait.cohort34.accounting.dto;

import lombok.Getter;

@Getter
public class UserEditDto {
    String firstName;
    String lastName;
}
