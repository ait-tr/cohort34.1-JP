package ait.imagga.dto;

import lombok.Getter;

import java.util.List;

@Getter
public class ResultDto {
    private List<TagDto> tags;
}
