package ait.imagga.dto;

import lombok.Getter;

@Getter
public class ResponseDto {
    private ResultDto result;
}
