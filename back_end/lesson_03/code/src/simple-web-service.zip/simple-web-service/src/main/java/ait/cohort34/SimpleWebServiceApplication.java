package ait.cohort34;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleWebServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(SimpleWebServiceApplication.class, args);
    }

}
