package ait.cohort34.dto;

import lombok.Getter;

@Getter
public class PersonDto {
    String firstName;
    String lastName;
}
