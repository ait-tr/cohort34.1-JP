package ait.imagga.dto;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonAlias;

import lombok.Getter;

@Getter
public class ImageColorsDto {
	@JsonAlias("image_colors")
	ColorDto[] imageColors;
	@JsonAlias("background_colors")
	ColorDto[] backgroundColors;
	@JsonAlias({"foreground_colors"})
    ColorDto[] foregroundColors;

	public List<ColorDto> getListOfCollors(){
		List<ColorDto> res = new ArrayList<>(Arrays.asList(imageColors));
		res.addAll(Arrays.asList(foregroundColors));
		res.addAll(Arrays.asList(backgroundColors));
		return res;
				
	}

	

}
