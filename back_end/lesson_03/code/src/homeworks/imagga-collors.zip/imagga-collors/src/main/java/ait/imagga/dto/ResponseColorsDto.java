package ait.imagga.dto;

import lombok.Getter;

@Getter
public class ResponseColorsDto {
	ResultColorsDto result;
	
}
