package ait.imagga.dto;

import com.fasterxml.jackson.annotation.JsonAlias;

import lombok.Getter;

@Getter
public class ColorDto {

	@JsonAlias("closest_palette_color_parent")
	String closestPaletteColorParent;
	@JsonAlias("closest_palette_color")
	String closestPaletteColor;
	Double percent;

	@Override
	public String toString() {
		return closestPaletteColor + "\t\t" + closestPaletteColorParent + "\t\t" + percent;
	}

}
