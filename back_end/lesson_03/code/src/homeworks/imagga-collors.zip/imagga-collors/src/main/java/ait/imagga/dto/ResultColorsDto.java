package ait.imagga.dto;

import lombok.Getter;

@Getter
public class ResultColorsDto {
	ImageColorsDto colors;

}
