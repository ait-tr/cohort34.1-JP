package ait.cohort34.person.service;

import ait.cohort34.person.dto.PersonDto;

public interface PersonService {
    Boolean addPerson(PersonDto personDto);
}
