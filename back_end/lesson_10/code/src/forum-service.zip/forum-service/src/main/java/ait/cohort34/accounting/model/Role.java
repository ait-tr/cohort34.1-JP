package ait.cohort34.accounting.model;

public enum Role {
    USER, MODERATOR, ADMINISTRATOR;
}
