package ait.cohort34.post.dao;

import ait.cohort34.post.model.Post;
import org.springframework.data.repository.CrudRepository;

public interface PostRepository extends CrudRepository<Post, String> {
}
