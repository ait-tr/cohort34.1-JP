package ait.cohort34.person.dto;

import lombok.Getter;

@Getter
public class ChildDto extends PersonDto{
    String kindergarten;
}
