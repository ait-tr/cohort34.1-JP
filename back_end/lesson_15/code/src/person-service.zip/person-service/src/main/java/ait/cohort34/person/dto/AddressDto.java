package ait.cohort34.person.dto;

import lombok.Getter;

@Getter
public class AddressDto {
    String city;
    String street;
    Integer building;
}
