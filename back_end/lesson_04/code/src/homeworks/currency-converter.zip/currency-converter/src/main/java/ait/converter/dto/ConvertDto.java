package ait.converter.dto;

import lombok.Getter;

@Getter
public class ConvertDto {
    private double result;
}
