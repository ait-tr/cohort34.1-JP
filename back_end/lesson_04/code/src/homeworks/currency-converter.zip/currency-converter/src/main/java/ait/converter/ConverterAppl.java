package ait.converter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URISyntaxException;

import ait.converter.dto.ConvertDto;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;


public class ConverterAppl {
    static final String API_KEY = "your api key";
    static RestTemplate restTemplate = new RestTemplate();
    static String url = "https://api.apilayer.com/fixer/convert";

    public static void main(String[] args) throws URISyntaxException {

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.println("Enter currency from: ");
            String from = reader.readLine().trim();
            System.out.println("Enter currency to: ");
            String to = reader.readLine().trim();
            System.out.println("Enter sum: ");
            double sum = Double.parseDouble(reader.readLine());
            HttpHeaders headers = new HttpHeaders();
            headers.add("apikey", API_KEY);
            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                    .queryParam("amount", sum)
                    .queryParam("from", from)
                    .queryParam("to", to);
            RequestEntity<String> request = new RequestEntity<>(headers, HttpMethod.GET, builder.build().toUri());
            ResponseEntity<ConvertDto> response = restTemplate.exchange(request, ConvertDto.class);
            double res = response.getBody().getResult();
            System.out.println("Result: " + res);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("I/O ERROR");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Incorrect arguments");
        }

    }

}
