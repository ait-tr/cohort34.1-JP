package ait.cohort34.student.dto;

import lombok.Getter;

@Getter
public class ScoreDto {
    private String examName;
    private int score;
}
