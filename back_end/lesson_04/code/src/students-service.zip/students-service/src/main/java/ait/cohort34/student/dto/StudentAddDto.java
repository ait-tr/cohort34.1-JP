package ait.cohort34.student.dto;

import lombok.Getter;

@Getter
public class StudentAddDto {
    private int id;
    private String name;
    private String password;
}
